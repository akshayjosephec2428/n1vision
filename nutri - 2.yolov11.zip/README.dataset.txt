# nutri - 2 > nutri-2
https://universe.roboflow.com/alvin-reju-mathew-s-workspace/nutri-2

Provided by a Roboflow user
License: CC BY 4.0

